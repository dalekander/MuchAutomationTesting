package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object URL
     
    /**
     * <p></p>
     */
    public static Object username
     
    /**
     * <p></p>
     */
    public static Object password
     
    /**
     * <p></p>
     */
    public static Object reassignment_user
     
    /**
     * <p></p>
     */
    public static Object specialvisitresult_testing_comment
     
    /**
     * <p></p>
     */
    public static Object ExportType
     
    /**
     * <p></p>
     */
    public static Object ImportFileName
     
    /**
     * <p></p>
     */
    public static Object BSL_URL
     
    /**
     * <p></p>
     */
    public static Object selectedContracNo_EI
     
    /**
     * <p></p>
     */
    public static Object selectedVisitCaseID_EI
     
    /**
     * <p></p>
     */
    public static Object selectedContracNo_MA
     
    /**
     * <p></p>
     */
    public static Object selectedVisitCaseID_MA
     
    /**
     * <p></p>
     */
    public static Object selectedCreationDate_MA
     
    /**
     * <p></p>
     */
    public static Object selectedContracNo_RA
     
    /**
     * <p></p>
     */
    public static Object selectedVisitCaseID_RA
     
    /**
     * <p></p>
     */
    public static Object selectedCreationDate_RA
     
    /**
     * <p></p>
     */
    public static Object selectedVisitCaseID_SVR
     
    /**
     * <p></p>
     */
    public static Object selectedContracNo_SVR
     
    /**
     * <p></p>
     */
    public static Object selectedCreationDate_SVR
     
    /**
     * <p></p>
     */
    public static Object visit_id
     
    /**
     * <p></p>
     */
    public static Object contract_no
     
    /**
     * <p></p>
     */
    public static Object creation_date
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            URL = selectedVariables['URL']
            username = selectedVariables['username']
            password = selectedVariables['password']
            reassignment_user = selectedVariables['reassignment_user']
            specialvisitresult_testing_comment = selectedVariables['specialvisitresult_testing_comment']
            ExportType = selectedVariables['ExportType']
            ImportFileName = selectedVariables['ImportFileName']
            BSL_URL = selectedVariables['BSL_URL']
            selectedContracNo_EI = selectedVariables['selectedContracNo_EI']
            selectedVisitCaseID_EI = selectedVariables['selectedVisitCaseID_EI']
            selectedContracNo_MA = selectedVariables['selectedContracNo_MA']
            selectedVisitCaseID_MA = selectedVariables['selectedVisitCaseID_MA']
            selectedCreationDate_MA = selectedVariables['selectedCreationDate_MA']
            selectedContracNo_RA = selectedVariables['selectedContracNo_RA']
            selectedVisitCaseID_RA = selectedVariables['selectedVisitCaseID_RA']
            selectedCreationDate_RA = selectedVariables['selectedCreationDate_RA']
            selectedVisitCaseID_SVR = selectedVariables['selectedVisitCaseID_SVR']
            selectedContracNo_SVR = selectedVariables['selectedContracNo_SVR']
            selectedCreationDate_SVR = selectedVariables['selectedCreationDate_SVR']
            visit_id = selectedVariables['visit_id']
            contract_no = selectedVariables['contract_no']
            creation_date = selectedVariables['creation_date']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
