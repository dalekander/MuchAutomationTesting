<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>MUCH Regress Test</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>d4a4232e-2c92-474b-a808-e2a0ed003aa5</testSuiteGuid>
   <testCaseLink>
      <guid>e3d6b91c-82b2-48d3-9939-24d9d8d07cc8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Manual Assignment Testing</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>752dc7a3-70e2-48d0-98fa-a61e5f9ddb9e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Reassignment Testing</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>445ce464-9545-4111-bd50-01910c452201</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Special Visit Result Testing</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e9074161-aab7-430b-8db9-2de218c4002f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Export Import Testing</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7a96b289-de5d-452a-a518-3488b742758a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Payment Testing</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
