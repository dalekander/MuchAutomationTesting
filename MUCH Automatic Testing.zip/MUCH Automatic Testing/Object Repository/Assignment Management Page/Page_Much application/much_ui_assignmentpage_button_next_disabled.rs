<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>much_ui_assignmentpage_button_next_disabled</name>
   <tag></tag>
   <elementGuidId>a4fbeb13-e78d-4ac9-a74a-1863950e7b96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@aria-label=&quot;Next Page&quot; and contains(@class, 'Mui-disabled')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1579600525253</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>screenshot</name>
      <type>Main</type>
      <value>C:/Users/daniel.alekander/Katalon Studio/MUCH Automatic Testing/Screenshots/Targets/Element_1579600525253.png</value>
   </webElementProperties>
</WebElementEntity>
